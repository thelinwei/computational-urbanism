# Pilot 03 — Does the Network Carry the Signal?

A first, narrower validation step ahead of the full graph-diffusion model
(the ρ-parameterised affordance-exposure equation, Plate 01 on the landing
page): does SVI-invisibility itself cluster more strongly along the
covered pedestrian network's own connectivity than along simple
geographic proximity?

**Result.** Within a bounded pilot area (7,970 covered segments), Global
Moran's I rises from 0.64 (simple proximity, KNN-6) to 0.79
(walkway-connectivity graph) for SVI-visibility — a +0.15 gap,
significant at p<0.001 under 999 permutations. Local Moran (LISA)
localises this into 624 segments in a significant invisible cluster
(HH), 1,230 in a visible cluster (LL), and 27 spatial outliers (HL/LH) —
the natural shortlist for future fieldwork.

**What this does not show.** It is a test of whether a purely
open-data-derived property (SVI-visibility) propagates along network
structure — not a test of whether social life, care, or holding does.
It uses no affordance/capacity data (none exists as a saved file yet;
see notebook §8, limitation 4) and no fieldwork. It is a validated
stepping stone toward the fuller diffusion model, not a substitute for it.

## Contents
- `notebooks/03_network_vs_proximity_pilot.ipynb` — executed notebook, all cells run, real outputs
- `data/moran_comparison.csv` — global Moran's I under both weights matrices
- `data/pilot03_lisa.geojson` — per-segment LISA cluster classification (HH/LL/HL/LH/ns)
- `figures/moran_comparison.png`, `figures/lisa_cluster_map.png`

## Reproducing
Requires `geopandas`, `networkx`, `libpysal`, `esda`, `mapclassify`, `matplotlib`.
Input is `sg_covered_ways_svi_visibility.geojson` (Pilot 01's output) — not
included here to avoid duplicating a large file; point the notebook's
`DATA` path at your existing copy.

## Limitations (stated plainly, not apologised for)
1. The 40 m bridge cutoff for stranded segments is a modelling choice —
   next step is a sensitivity sweep across cutoffs, matching the
   discipline of Pilots 01–02.
2. One bounded pilot area, chosen for tractability — a proof of concept,
   not a citywide claim yet.
3. `dist_to_road_m` inherits every caveat from Pilot 01 §9.
4. No affordance/capacity variable yet — re-run this comparison once
   Pilot 02's affordance overlay exists as a saved file, not just a
   plotted figure.
